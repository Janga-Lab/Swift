#' Checks to see if Blast is installed and locatiable
#' @keywords installed
#' @export
#' @examples
#' CheckDL()
#'
CheckDL <- function(){
  blast.dir <<- system(command = "which blastn", intern = TRUE)
  if (substring(blast.dir,1,1) == "/") {
    print("Local Blast intall directory found!")
    print(blast.dir)} else{
    print("Must have Blast+ installed & configured locally")
}}
