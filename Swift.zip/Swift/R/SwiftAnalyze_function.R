#' Asks user to select file and specify its type
#' @param Evalue the e value cuttoff value as a decimal
#' @param LenFilter the filterd length of the sequences
#' @param PerID the percentage the sequence shares in the subject
#' @param SpeciesFilter the number of species a sequence must occur in
#' @param NewFileName the name of your filter resultsfile.txt
#' @param ResultsName The name of your resultsfile
#' @keywords Search blast
#' @export
#' @examples
#'SearchBlast("/Path/To/resultsfile.txt","FilteredResultsFile.txt","est")
#'
SwiftAnalyze <- function(ResultsName = "ResultsFile.txt", Evalue = "0.00000000000000000000000000000000000000000000000001", LenFilter = 400, PerID = 70, SpeciesFilter = 1, NewFileName = "FilteredResults.txt"){
  outputFeilds <- "qseqid sacc qlen length slen pident nident qstart qend evalue bitscore scomnames sskingdoms"
  CompleteList <-data.table::as.data.table(read.table("TotalIDlist.txt", quote="\"", comment.char=""))
  CompleteList <- data.table::as.data.table(lapply(CompleteList, gsub, pattern= '>', replacement = ''))
  RawResultsFile <- data.table::as.data.table(read.delim(ResultsName, header=FALSE))
  NoHitNCTs <- data.table::as.data.table(unique(setdiff(CompleteList$V1,RawResultsFile$V1)))
  titles <- as.character(strsplit(outputFeilds, '\\s+')[[1]])
  evalueCol <- match("evalue", titles)
  system(command = paste("awk '($",evalueCol,"+ 0) <", Evalue,"'",ResultsName," >", NewFileName))
  ResultsFile <- data.table::as.data.table(read.delim(NewFileName, header=FALSE))
  colnames(ResultsFile) <- titles
  colnames(ResultsFile)[colnames(ResultsFile)=="sacc"] <- "ACCNUM"
  ResultsFile <- ResultsFile[(ResultsFile$qlen >= LenFilter),]
  ResultsFile$PerMatch <- (ResultsFile$nident / ResultsFile$qlen) * 100
  ResultsFile <- ResultsFile[(ResultsFile$PerMatch >= PerID),]
  requireNamespace("dplyr")
  NCTspeciesCount <- ResultsFile %>%
    group_by(qseqid) %>%
    summarise(n_distinct(scomnames))

  colnames(NCTspeciesCount) <- c("qseqid","Num_Of_Species")
  NCTspeciesCount <- as.data.frame(NCTspeciesCount)
  d <- density(NCTspeciesCount$Num_Of_Species) # returns the density data
  plot(d)

  FilteredSpecies <- NCTspeciesCount %>%
    group_by(qseqid) %>%
    dplyr::filter(!any(Num_Of_Species <= SpeciesFilter))


  ResultsFile <- merge(ResultsFile, FilteredSpecies)
  NCTperSpeciesCount <- ResultsFile %>% group_by(qseqid, scomnames) %>% summarize(count=n())
  ResultsFile <- unique(ResultsFile)
  ResultsFile$ACCNUM <- as.character(ResultsFile$ACCNUM)

  dbMap <- read.delim(paste0(path.package("Swift"), "/dbmap.txt"))
  dbMap <-unique.data.frame(dbMap, stringsAsFactors = FALSE)
  orgdbinstallnames <- as.character(dbMap$dbName)
  lapply(orgdbinstallnames, require, character.only = TRUE)

  mappedTotal <- data.frame(matrix(ncol = 4, nrow = 1))
  colnames(mappedTotal) <- c("ACCNUM","ENTREZID","SYMBOL","GENENAME")
  for (i in dbMap$dbName){tryCatch({
    a = get(i)
    #mapped <- select(org.Hs.eg.db, ResultsFile$ACCNUM, c("ENTREZID","SYMBOL","GENENAME"), "ACCNUM")
    mapped <- select(a,ResultsFile$ACCNUM, c("ENTREZID","SYMBOL","GENENAME"), "ACCNUM")
    mapped <- unique(mapped)
    mapped <- drop_na(mapped)
    mappedTotal <- rbind(mappedTotal, mapped)
  },
  error=function(e){cat(paste("The",i, "database does not contain any results.", "\n"))}
  )
  }

  mappedTotal <- unique(mappedTotal)
  mappedTotal <- na.omit(mappedTotal)
  ResultsFile2<- merge(ResultsFile, mappedTotal, by = "ACCNUM", all=TRUE)

  write.table(ResultsFile2$ACCNUM, file = "NCTaccessions.txt", quote= FALSE, sep = "\t",
              row.names = FALSE)
  write.table(ResultsFile2, file = NewFileName, quote= FALSE, sep = "\t",
              row.names = FALSE)
  write.table(NoHitNCTs, file = "NoHitNCTs.txt", quote= FALSE, sep = "\t",
              row.names = FALSE)
  write.table(NCTperSpeciesCount, file = "NCTspeciesBreakdown.txt", quote= FALSE, sep = "\t",
              row.names = FALSE)
  write.table(NCTspeciesCount, file = "NCTspeciesCount.txt", quote= FALSE, sep = "\t",
              row.names = FALSE)
}
