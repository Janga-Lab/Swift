#' Asks user to select file and specify its type
#' @param Type the type of file being selected
#' @param fileName The name of your input file
#' @keywords file
#' @export
#' @examples
#'LoadData("fasta","MyFasta.fa")
#'
LoadData<- function(Type = "fasta", fileName = "Test.fa"){
  inputFile <<- fileName
  system(command = paste("awk -F '[| ]' '/^>/ { print $1}' < ",inputFile,"> TotalIDlist.txt"))
  if (Type == "bam"){
    what <- c( "qname", "seq","rname", "strand","pos", "qwidth")
    param <- ScanBamParam(what = what)
    bam <- scanBam(inputFile,param = param)
    bam <- unname(bam)
    elts <- setNames(bamWhat(param), bamWhat(param))
    .unlist <- function (x){
      x1 <- x[[1L]]
      if (is.factor(x1)) {
        structure(unlist(x), class = "factor", levels = levels(x1)) }else{
          do.call(c, x)
        }
    }
    lst <- lapply(elts, function(elt) .unlist(lapply(bam, "[[", elt)))
    BamDf<- as.data.frame(do.call("DataFrame", lst))
    BamDf <- BamDf[is.na(BamDf$rname),]
    FastaFile <- as.data.frame(paste0(">",BamDf$qname))
    FastaSeqs <- as.data.frame(BamDf$seq)

    #Provided by Mark Heckmann
    zipFastener <- function(df1, df2, along=2)
    {
      # parameter checking
      if(!is.element(along, c(1,2))){
        stop("along must be 1 or 2 for rows and columns
             respectively")
      }
      # if merged by using zip feeding along the columns, the
      # same no. of rows is required and vice versa
      if(along==1 & (ncol(df1)!= ncol(df2))) {
        stop ("the no. of columns has to be equal to merge
              them by zip feeding")
      }

      # zip fastener preperations
      d1 <- dim(df1)[along]
      d2 <- dim(df2)[along]
      i1 <- 1:d1           # index vector 1
      i2 <- 1:d2 + d1      # index vector 2

      # set biggest dimension dMax
      if(d1==d2) {
        dMax <- d1
      } else if (d1 > d2) {
        length(i2) <- length(i1)    # make vectors same length,
        dMax <- d1                  # fill blanks with NAs
      } else  if(d1 < d2){
        length(i1) <- length(i2)    # make vectors same length,
        dMax <- d2                  # fill blanks with NAs
      }
      # zip fastener operations
      index <- as.vector(matrix(c(i1, i2), ncol=dMax, byrow=T))
      index <- index[!is.na(index)]         # remove NAs

      if(along==1){
        colnames(df2) <- colnames(df1)   # keep 1st colnames
        res <- rbind(df1,df2)[ index, ]  # reorder data frame
      }

      return(res)
      }
    FF<-zipFastener(FastaFile,FastaSeqs,1)
    write.table(FF, file = "FastaFile.fa", quote= FALSE,
                row.names = FALSE, col.names = FALSE)
    print("Please select the FastaFile.fa generated from your BAM file")
    inputFile <<- file.choose()
    system(command = paste("awk -F '[| ]' '/^>/ { print $1}' < ",inputFile,"> TotalIDlist.txt"))

  }

}

