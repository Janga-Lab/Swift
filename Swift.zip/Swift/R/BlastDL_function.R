#' A function to download NCBI's BLAST
#'
#' This function downloads NCBI's BLAST to your working direcotry.
#' @keywords Blast
#' @export
#' @examples
#' BlastDL()

BlastDL <- function(){
    url <- "ftp://ftp.ncbi.nlm.nih.gov/blast/executables/LATEST//ncbi-blast-2.8.1+-x64-linux.tar.gz"
    download.file(url,"ncbi-blast-2.8.1+-x64-linux.tar.gz")
    system(command = "tar zxvpf ncbi-blast-2.8.1+-x64-linux.tar.gz")
    blast.dir <<- system(command = "which blastn", intern = TRUE)
    if (substring(blast.dir,1,1) == "/") {
      print("Local Blast intall directory found!")
      print(blast.dir)} else{
      print("Must have Blast+ installed & configured locally")
      }
  }
